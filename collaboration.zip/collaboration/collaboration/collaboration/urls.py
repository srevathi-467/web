"""
URL configuration for collaboration project.

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/4.2/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path
from collabapp import views

urlpatterns = [
    path('admin/', admin.site.urls),
    path('',views.home),
    path('login/',views.user_login),
    path('signup/',views.signup),
    path('ttsignup/',views.ttsignup),
    path('taskasg/',views.taskasg),
    path('admintaskasg/',views.admintaskasg),
    path('addtask/',views.addtask),
    path('users/',views.users),
    path('deluser/<id>/',views.deluser),
    path('taskdelete/<id>/',views.notedelete),
    path('taskedit/<id>/',views.noteedit),
    path('share/',views.share),
    path('ttlogin/<id>/',views.tuser_login),
    path('logout/',views.logout),
    path('notes/',views.notes),
    path('addnote/',views.addnote),
    path('opennote/<id>/',views.opennote),
    path('notedel/<id>/',views.notedel),
    path('noteedit/<id>/',views.noteeditt),
    path('complete/<id>/',views.complete),
    path('veryficat/<id>/',views.veryficat),
    path('payment/',views.payment),
    path('addlist/',views.addlist),
    path('list/',views.list),
    path('listdel/<id>/',views.listdel),
    path('plus/<id>/',views.plus)

]
