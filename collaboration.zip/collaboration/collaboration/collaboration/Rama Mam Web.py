first install python
install xamp
go to cmd and type pip install django & pip install mysqlclient   

instalation fished 




go project directors and type cmd       


if first time to run another lap :
    (
    and type python manage.py makemigrations
    python manage.py migrate
    )
else:
    python manage.py runserver
i think this methoden is very uysefull to better understanding🤣😂


