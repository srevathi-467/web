from django.db import models

# forms.py
from django import forms

class PaymentForm(forms.Form):
    amount = forms.DecimalField(label='Amount', min_value=1, max_digits=10, decimal_places=2)
    name = forms.CharField(label='Name', max_length=100)
    email = forms.EmailField(label='Email')
    


class adlist(models.Model):
    nouser = models.CharField(max_length=200)
    ms = models.CharField(max_length=200)

class listt(models.Model):
    otp = models.CharField(max_length=200)
    userna = models.CharField(max_length=200)
    name = models.CharField(max_length=200)
    edate = models.DateTimeField()
    


class task(models.Model):
    otp = models.CharField(max_length=200)
    verifyby = models.CharField(max_length=100,null=True)
    verify = models.CharField(max_length=100,null=True)
    comverify = models.CharField(max_length=100,null=True)
    task = models.CharField(max_length=200)
    taskdate = models.DateField()
    emal = models.CharField(max_length=200) 

class oott(models.Model):
    uname = models.CharField(max_length=100, null=True)
    tname =models.CharField(max_length=100) 
    otp = models.CharField(max_length=10)
    gotp = models.CharField(max_length=10)
    pas = models.CharField(max_length=50)


class notesss(models.Model):
    otp = models.CharField(max_length=200)
    tile = models.CharField(max_length=200)
    note = models.CharField(max_length=200)
    notedate = models.CharField(max_length=10)
   