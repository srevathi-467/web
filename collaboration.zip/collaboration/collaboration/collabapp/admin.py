from django.contrib import admin
from .models import task,oott,adlist
# Register your models here.
admin.site.register(task)
admin.site.register(oott)
admin.site.register(adlist)