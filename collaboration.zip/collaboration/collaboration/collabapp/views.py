from django.shortcuts import render
from django.shortcuts import render, redirect
from django.contrib.auth import login, authenticate
from django.contrib.auth.models import User
from django.contrib import messages 
from collabapp.models import task,notesss,listt,adlist
from django.core.mail import send_mail
from django.http import HttpResponse
from django.contrib.auth import logout as auth_logout
from django.shortcuts import redirect
from datetime import datetime



# views.py
import razorpay
from collaboration import settings
from django.shortcuts import render, redirect

def create_razorpay_order(amount):
    client = razorpay.Client(auth=(settings.RAZORPAY_API_KEY, settings.RAZORPAY_API_SECRET))
    data = {
        'amount': int(amount * 100),  # Razorpay expects the amount in paise
        'currency': 'INR',  # Change this to your currency code
    }
    order = client.order.create(data=data)
    print(order['id'])
    return order['id']
from django.urls import reverse
def payment(request):
    if request.method == 'POST':
        amount = float(request.POST.get('amount'))
        order_id = create_razorpay_order(amount)
        return redirect('/payment')
    return render(request,'payment.html')







def addlist(request):
    user = request.user
    dd = user.username
    tuser = oott.objects.get(uname = dd)
    otttp = tuser.otp
    if request.method == 'POST':
        cc = request.POST['name']
        tt = request.POST['edate']
        listt.objects.create( otp = otttp, userna = dd, name = cc, edate = tt)
        return redirect('/list')
    return render(request,'addlist.html')

def list(request):
    user = request.user
    dd = user.username

    tuser = listt.objects.filter(userna = dd)
    return render(request,'list.html',{'data':tuser})

def listdel(request,id):
    ddp = listt.objects.get(id = id)
    ddp.delete()
    return redirect('/list')







def logout(request):
   auth_logout(request)
   return redirect('/')



def notedelete(request,id):
    ttt = task.objects.get(id = id)
    ttt.delete()
    return redirect('/taskasg')
    
from datetime import datetime 
def noteedit(request,id):
    ttt = task.objects.get(id = id)
    if request.method == 'POST':
        ttt.task= request.POST['name']
        ttt.taskdate= request.POST['birthdate']
        ttt.emal= request.POST['email']
        ttt.save()
        return redirect('/taskasg')
    return render(request,'noteedit.html',{'data':ttt})  

def addtask(request):
    try:
        if request.method == 'POST':
            taskk = request.POST['name']
            taskdate = request.POST['birthdate']
            emal = request.POST['email']
            subject = 'Task assigned to you from collaboration team.'
            message = taskk
            from_email = 'abishekk14052022@gmail.com'
            recipient_list = [emal]
            send_mail(subject, message, from_email, recipient_list)
            user = request.user
            tuser = oott.objects.get(uname = user)
            otttp = tuser.otp
            task.objects.create(otp = otttp,task=taskk,taskdate=taskdate,emal=emal)
            return redirect('/taskasg')
    except:
        messages.success(request, 'enter the correct email address')
        return redirect('/addtask')
    return render(request,'addtask.html')

def complete(request, id):
    rrr = task.objects.get(id =id)
    user = request.user
    dd = user.username
    
    if rrr.comverify == None:
        rrr.comverify = user.username
        rrr.verify = 'verification pending'
        rrr.save()
    else:
        messages.success(request,'the task is already completed by ' + rrr.comverify + '')
    return redirect('/taskasg')

def veryficat(request,id):
    rrr = task.objects.get(id =id)
    print('hi')
    user = request.user
    uname = user.username
    txt = rrr.verify
    if rrr.comverify == uname:
        messages.success(request,'Verification can only be done by our team members.')
    else:
        if rrr.verify == 'completed':
            messages.success(request,'Alreay verified')
            return redirect('/taskasg')
        if rrr.comverify == None:
            messages.success(request,'No one completed the task')
            return redirect('/taskasg')
        rrr.verify = 'completed'
        rrr.verifyby = 'verified by '+ uname +''
        rrr.save()
    user = request.user
    tuser = oott.objects.get(uname = user)
   
    if tuser.tname == 'Head':
        return redirect('/admintaskasg')
    return redirect('/taskasg')
    

def home(request):
    return render(request,'home.html')


def share(request):
    user = request.user
    tuser = oott.objects.get(uname = user)
    op = tuser.otp
    return render(request,'share.html',{'ot':op})

def plus(request,id):
    
    user = request.user
    tuser = oott.objects.get(uname = user)
    ot = tuser.otp
    autoveri = oott.objects.filter(otp = ot)  
    if request.method == 'POST':
        selected_checkboxes = request.POST.getlist('chet')
        lms = listt.objects.get(id = id)
        ms = lms.name
        for x in selected_checkboxes:
            exists = adlist.objects.filter(nouser=x,ms =ms).exists()
            if exists:
                continue
            adlist.objects.create(nouser = x,ms = ms)
        return redirect('/list')
    return render(request,'plus.html',{'data':autoveri})



import random
from .models import oott
def ttsignup(request):
    user = request.user
    tuser = oott.objects.get(uname = user)
    otttp = tuser.otp
    pay = oott.objects.filter(otp = otttp)
    count = pay.count()
    if request.method == 'POST':
        user = request.user
        tuser = oott.objects.get(uname = user)
        otttp = tuser.otp
        random_4_digit = random.randint(1000, 9999)
        username = request.POST['username']
        password = request.POST['password']
        email = request.POST['email']
        subject = 'collaboration team.'
        
        message = 'Account created successfully  \n login link: http://127.0.0.1:8000/ttlogin/'+str(random_4_digit)+'\n username:' + username + ' \n password:'+ password + ''
        
        from_email = 'abishekk14052022@gmail.com'
        recipient_list = [email]
        send_mail(subject, message, from_email, recipient_list)
        user = User.objects.create_user(username=username, password=password,email = email)
        oott.objects.create(uname = username, pas = password, gotp = random_4_digit ,tname = 'user' , otp = tuser.otp)
        
        #messages.success(request, )
        return redirect('/users')
    return render(request, 'signupform.html')


def signup(request):
    if request.method == 'POST':
        username = request.POST['username']
        password = request.POST['password']
        email = request.POST['email']
        subject = 'collaboration team.'
        message = 'Account created successfully '
        from_email = 'abishekk14052022@gmail.com'
        recipient_list = [email]
        send_mail(subject, message, from_email, recipient_list)
        user = User.objects.create_user(username=username, password=password,email = email)
        random_4_digit = random.randint(1000, 9999)
        oott.objects.create(uname = username , tname = 'Head' , otp = random_4_digit)
        login(request, user)
        messages.success(request, 'The password was created successfully.')
        return redirect('/login')  
    return render(request, 'signupform.html')



def user_login(request):
    if request.method == 'POST':
        username = request.POST['username']
        password = request.POST['password']
        user = authenticate(request, username=username, password=password)
        try:
            gg = oott.objects.get(uname = username)
            if user is not None and gg.uname:
                login(request, user)
                return redirect('/admintaskasg')  
        except:   
                error_message = "Invalid username or password."
                messages.success(request, 'Invalid username or password')
    else:
        error_message = ""
    error_message = ""
 
    return render(request, 'loginform.html', {'error_message': error_message})




def tuser_login(request, id):
    autoveri = oott.objects.get(gotp = id)  
    vv = autoveri.uname
    gett = adlist.objects.filter(nouser = vv)
    username = autoveri.uname
    password = autoveri.pas
    user = authenticate(request, username=username, password=password)
    try:
        if user is not None:
            login(request, user)
           
            return redirect('/taskasg')
    except:
        error_message = "Invalid OTP."  
        messages.success(request, 'Invalid OTP')
    return render(request, 'loginform.html')


def admintaskasg(request):  
    user = request.user
    gett = adlist.objects.filter(nouser = user)
    tuser = oott.objects.get(uname = user)
    otttp = tuser.otp
    listtask = task.objects.filter(otp = otttp)   
    comlist = task.objects.filter(otp = otttp,verify = 'completed') 
    verlist = task.objects.filter(otp = otttp,verify = 'verification pending')   
    com = comlist.count()  
    ver = verlist.count()    
    return render(request, 'admintaskasg.html',{'data':listtask,'com':com,'ver':ver,'ter':gett,'user':user.username})




def taskasg(request):  
    user = request.user

    gett = adlist.objects.filter(nouser = user)
    tuser = oott.objects.get(uname = user)
    otttp = tuser.otp
    if tuser.tname == 'Head':
        return redirect('/admintaskasg')
    listtask = task.objects.filter(otp = otttp)         
    return render(request, 'taskinput.html',{'data':listtask,'user':user.username,'ter':gett})






def addnote(request):
    if request.method == 'POST':
        tile = request.POST['tile']
        note = request.POST['note']
        today = datetime.today()
        notedate = today.strftime('%d/%m/%Y')
        user = request.user
        tuser = oott.objects.get(uname = user)
        otttp = tuser.otp
        notesss.objects.create(otp = otttp,tile = tile,note = note,notedate = notedate)
        return redirect('/notes')
    return render(request,'addnote.html')



def notedel(request,id):
    note = notesss.objects.get(id = id)
    note.delete()
    return redirect('/notes')
def noteeditt(request,id):
    gg = notesss.objects.get(id = id)
    if request.method == 'POST':
        tile = request.POST['tile']
        note = request.POST['note']
        today = datetime.today()
        notedate = today.strftime('%d/%m/%Y')
        user = request.user
        tuser = oott.objects.get(uname = user)
        otttp = tuser.otp
        gg.tile = tile
        gg.note = note
        gg.otp = otttp
        gg.notedate = notedate
        gg.save()
        return redirect('/notes')
        
    return render(request,'nnoteedit.html',{'x':gg})
   

def notes(request):
    user = request.user
    tuser = oott.objects.get(uname = user)
    otttp = tuser.otp
    listnotes = notesss.objects.filter(otp = otttp)
    return render(request, 'notes.html',{'data':listnotes})

def opennote(request,id):
    user = request.user
    tuser = oott.objects.get(uname = user)
    otttp = tuser.otp
    listnotes = notesss.objects.filter(otp = otttp,id = id)
    return render(request, 'opennote.html',{'data':listnotes})


def users(request):
    user = request.user
    tuser = oott.objects.get(uname = user)
    otttp = tuser.otp
    aduser = oott.objects.filter(tname = 'Head' , otp = otttp)
    userrr = oott.objects.filter(tname = 'user' , otp = otttp)       
    return render(request, 'users.html',{'aduser':aduser,'us':userrr,})





def deluser(request,id):
    try:
        u = oott.objects.get(id=id)
        try:
            userd = User.objects.get(username=u.uname)
            userd.delete()
        except User.DoesNotExist:
            # Handle the case where the User doesn't exist
            pass
        
        u.delete()
        
        return redirect('/users')
    except User.DoesNotExist:
        messages.error(request, 'User does not exist.')   
        return redirect('/users')      
    

    